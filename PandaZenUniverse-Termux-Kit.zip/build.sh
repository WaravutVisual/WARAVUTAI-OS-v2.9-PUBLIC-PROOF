#!/data/data/com.termux/files/usr/bin/bash
# PandaZenUniverse Portal - Termux Builder v2.9
# by Waravut AI Phonyeam

set -e

echo "🐼 PandaZenUniverse - Termux Builder"
echo "====================================="

# 1. Update & install deps
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git python

# 2. Create project
PROJECT=~/PandaZenUniverse-Portal
mkdir -p $PROJECT
cd $PROJECT

echo "📦 Init project..."
npm init -y
npm install vite react react-dom
npm install -D @vitejs/plugin-react

# 3. Create vite config
cat > vite.config.js <<'VITE'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  server: { host: '0.0.0.0', port: 5173 }
})
VITE

# 4. Create index.html
cat > index.html <<'HTML'
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>PandaZenUniverse Portal | WARAVUTAI OS</title>
<link rel="manifest" href="/manifest.json">
</head>
<body>
<div id="root"></div>
<script type="module" src="/src/main.jsx"></script>
</body>
</html>
HTML

mkdir -p src

# 5. Copy your real portal code
# ถ้าคุณมีไฟล์ pandazenuniverse_portal_agentic_artifact_3_fb6688e37756.html ให้วางทับ src/App.jsx
cat > src/main.jsx <<'JSX'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
ReactDOM.createRoot(document.getElementById('root')).render(<App/>)
JSX

# Create App.jsx - simplified version of PandaZenUniverse Portal
cat > src/App.jsx <<'APP'
import React, { useState } from 'react'

export default function App(){
  const [tab, setTab] = useState('home')
  return (
    <div style={{fontFamily:'system-ui', background:'#0a0a0f', color:'#fff', minHeight:'100vh'}}>
      <header style={{padding:'20px', borderBottom:'1px solid #222', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>🐼 PandaZenUniverse</h1>
        <nav style={{display:'flex', gap:12}}>
          <button onClick={()=>setTab('home')}>Home</button>
          <button onClick={()=>setTab('apps')}>Apps</button>
          <button onClick={()=>setTab('proof')}>Proof</button>
        </nav>
      </header>
      <main style={{padding:24}}>
        {tab==='home' && <>
          <h2>WARAVUTAI OS v2.9 - PandaZenUniverse Portal</h2>
          <p>Official Portal by Waravut AI Phonyeam</p>
          <p>Running on Termux ✅</p>
          <div style={{marginTop:20, display:'grid', gap:12, gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))'}}>
            <div style={{background:'#16161f', padding:16, borderRadius:12}}>🚀 PWA Ready</div>
            <div style={{background:'#16161f', padding:16, borderRadius:12}}>🔐 Proof of Ownership</div>
            <div style={{background:'#16161f', padding:16, borderRadius:12}}>📱 APK Builder</div>
          </div>
        </>}
        {tab==='apps' && <p>Apps & Tools will be here - WARAVUTAI APK BUILDER FULL</p>}
        {tab==='proof' && <p>MANIFEST.json / SHA256SUMS / DIP Certificate</p>}
      </main>
      <footer style={{padding:20, textAlign:'center', opacity:0.5}}>© 2026 Waravut AI Phonyeam - Sung Noen, Nakhon Ratchasima</footer>
    </div>
  )
}
APP

# 6. Manifest for PWA
cat > public/manifest.json 2>/dev/null || mkdir -p public && cat > public/manifest.json <<'MANI'
{
  "name": "PandaZenUniverse Portal",
  "short_name": "PandaZen",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0a0a0f",
  "theme_color": "#0a0a0f"
}
MANI

# If you have the real zip, unzip here
if [ -f ~/storage/downloads/WARAVUTAI-OS-v2.9-Correct-Name.zip ]; then
  echo "Found real ZIP in Downloads, extracting..."
  unzip -o ~/storage/downloads/WARAVUTAI-OS-v2.9-Correct-Name.zip -d $PROJECT/public/proof/
fi

echo ""
echo "✅ Build ready! To run:"
echo "cd $PROJECT && npx vite --host"
echo ""
echo "Then open http://localhost:5173 in browser"
echo ""
echo "To build APK with Termux:"
echo "npm install -g @bubblewrap/cli"
echo "bubblewrap init --manifest https://your-deployed-url/manifest.json"
echo "bubblewrap build"

# auto run
npx vite --host
