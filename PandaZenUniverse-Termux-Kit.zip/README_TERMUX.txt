PandaZenUniverse - Termux Build Kit
By Waravut AI Phonyeam

วิธีใช้ใน Termux:
1. termux-setup-storage
2. cp ~/storage/downloads/termux-build-pandazen.sh ~/
3. chmod +x ~/termux-build-pandazen.sh
4. bash ~/termux-build-pandazen.sh

หรือแตกไฟล์ Kit นี้แล้วรัน:
cd ~/PandaZenUniverse-Termux-Kit
bash build.sh

มันจะติดตั้ง Node.js + Vite และรันพอร์ทัลที่ http://localhost:5173

ถ้าต้องการสร้าง APK:
pkg install openjdk-17
npm i -g @bubblewrap/cli
bubblewrap init --manifest http://localhost:5173/manifest.json
bubblewrap build
