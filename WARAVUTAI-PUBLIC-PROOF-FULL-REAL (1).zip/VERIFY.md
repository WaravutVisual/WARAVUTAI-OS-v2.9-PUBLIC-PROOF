# VERIFY.md - How to Verify This Public Proof

This guide allows anyone to independently verify ownership of WARAVUTAI OS v2.9 without accessing private source code.

## Step 1: Download Evidence
Download all files from this public repo.

## Step 2: Calculate SHA-256
For each file in evidence/ folder, calculate SHA-256:

```bash
sha256sum evidence/*/* 
```

On Windows (PowerShell):
```powershell
Get-FileHash evidence/* -Algorithm SHA256
```

## Step 3: Compare with SHA256SUMS.txt
Compare calculated hashes with hashes listed in SHA256SUMS.txt
They must match exactly.

## Step 4: Verify Manifest
Open MANIFEST.json
Check:
- owner = Waravut Phonyeam
- project = WARAVUTAI-OS-v2.9
- commit = c3d9aa6
- release = v2.9

## Step 5: Verify Git Commit (Owner only or with access)
If you have access to private repo WaravutVisual/WARAVUTAI-OS-v2.9:
```bash
git show c3d9aa6 --show-signature
git tag --verify v2.9
```

## Step 6: Verify Tag/Release
Check release v2.9 exists in private repo and matches manifest.

## Step 7: Confirm Hash Chain
Open hashes/hash-chain.json
Verify chain: creation -> release -> public_proof
Each hash links to previous.

## Step 8: Record Verification Result
Result format:
```
VERIFIED: WARAVUTAI OS v2.9 owned by Waravut Phonyeam
Date: [verification date]
Verifier: [your name]
Hash Match: YES
Manifest Match: YES
Commit Verified: YES/NA
```

This changes from "I claim ownership" to "Here is artifact -> hash -> provenance -> verification method" - Strong evidence architecture.

## Public URL
https://github.com/Waravut/WARAVUTAI-OS-v2.9-PUBLIC-PROOF
Must return 200 OK, not 404.
If 404, owner must rename repo to ASCII-only name.
